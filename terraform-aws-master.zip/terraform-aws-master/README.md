
Using Terraform Variable to spin up an EC2 instance on AWS.
